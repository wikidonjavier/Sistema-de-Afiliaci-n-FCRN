
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { useGenealogy } from '@/contexts/GenealogyContext';
import { useToast } from '@/components/ui/use-toast';
import AddMemberDialog from '@/components/AddMemberDialog';
import TreeVisualization from '@/components/TreeVisualization';
import { Plus, Users, Download, Video } from 'lucide-react';

const FamilyTree = () => {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const { familyMembers } = useGenealogy();
  const { toast } = useToast();

  const handleGenerateVideo = () => {
    toast({
      title: "Video Generation",
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const handleExport = () => {
    toast({
      title: "Export Feature",
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <>
      <Helmet>
        <title>Family Tree - Sephardic Genealogy Research</title>
        <meta name="description" content="Visualize and manage your Sephardic family tree with interactive genealogy tools" />
      </Helmet>
      <Layout>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="space-y-8"
        >
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">Family Tree</h1>
              <p className="text-gray-600">Visualize and manage your family connections</p>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={handleGenerateVideo}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg"
              >
                <Video className="w-4 h-4 mr-2" />
                Generate Video
              </Button>
              <Button
                onClick={handleExport}
                variant="outline"
                className="border-2 border-gray-300 hover:border-amber-600 hover:bg-amber-50"
              >
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button
                onClick={() => setIsAddDialogOpen(true)}
                className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white shadow-lg"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Member
              </Button>
            </div>
          </div>

          {familyMembers.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-xl shadow-lg p-12 text-center border border-gray-200"
            >
              <Users className="w-20 h-20 text-gray-400 mx-auto mb-6" />
              <h2 className="text-2xl font-bold text-gray-900 mb-4">No Family Members Yet</h2>
              <p className="text-gray-600 mb-8">Start building your family tree by adding your first member</p>
              <Button
                onClick={() => setIsAddDialogOpen(true)}
                className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white shadow-lg"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add First Member
              </Button>
            </motion.div>
          ) : (
            <TreeVisualization members={familyMembers} />
          )}

          <AddMemberDialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen} />
        </motion.div>
      </Layout>
    </>
  );
};

export default FamilyTree;
