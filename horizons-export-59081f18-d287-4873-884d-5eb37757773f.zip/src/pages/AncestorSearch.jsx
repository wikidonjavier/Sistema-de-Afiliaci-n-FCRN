
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { useGenealogy } from '@/contexts/GenealogyContext';
import { useToast } from '@/components/ui/use-toast';
import { Search, Plus, MapPin, Calendar, Users, Sparkles } from 'lucide-react';

const AncestorSearch = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [location, setLocation] = useState('');
  const [timeframe, setTimeframe] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const { addFamilyMember, addSearchRecord } = useGenealogy();
  const { toast } = useToast();

  const mockResults = [
    {
      name: 'Isaac ben Abraham',
      birthYear: '1650',
      deathYear: '1720',
      location: 'Amsterdam, Netherlands',
      occupation: 'Merchant',
      notes: 'Part of the Portuguese Jewish community'
    },
    {
      name: 'Esther Rodrigues',
      birthYear: '1675',
      deathYear: '1745',
      location: 'Livorno, Italy',
      occupation: 'Unknown',
      notes: 'Married to a prominent rabbi'
    },
    {
      name: 'Moses de Castro',
      birthYear: '1690',
      deathYear: '1765',
      location: 'London, England',
      occupation: 'Physician',
      notes: 'Served the Bevis Marks Synagogue community'
    }
  ];

  const handleSearch = () => {
    if (!searchTerm) {
      toast({
        title: "Search Required",
        description: "Please enter a name to search",
        variant: "destructive"
      });
      return;
    }

    setIsSearching(true);
    
    setTimeout(() => {
      setSearchResults(mockResults);
      addSearchRecord({
        searchTerm,
        location,
        timeframe,
        resultsCount: mockResults.length
      });
      setIsSearching(false);
      toast({
        title: "Search Complete",
        description: `Found ${mockResults.length} potential matches`
      });
    }, 1500);
  };

  const handleAddToTree = (person) => {
    addFamilyMember({
      name: person.name,
      birthYear: person.birthYear,
      deathYear: person.deathYear,
      birthPlace: person.location,
      occupation: person.occupation,
      notes: person.notes
    });
    toast({
      title: "Added to Family Tree",
      description: `${person.name} has been added to your family tree`
    });
  };

  return (
    <>
      <Helmet>
        <title>Ancestor Search - Sephardic Genealogy Research</title>
        <meta name="description" content="Search for your Sephardic ancestors using our AI-powered genealogical database" />
      </Helmet>
      <Layout>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="space-y-8"
        >
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Ancestor Search</h1>
            <p className="text-gray-600">Search our database of Sephardic ancestors</p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Sparkles className="w-6 h-6 text-amber-600" />
              <h2 className="text-2xl font-bold text-gray-900">AI-Powered Search</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Search className="w-4 h-4 inline mr-2" />
                  Name
                </label>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Enter ancestor name..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all text-gray-900"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <MapPin className="w-4 h-4 inline mr-2" />
                  Location
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="City, Country"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all text-gray-900"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Calendar className="w-4 h-4 inline mr-2" />
                  Time Period
                </label>
                <input
                  type="text"
                  value={timeframe}
                  onChange={(e) => setTimeframe(e.target.value)}
                  placeholder="e.g., 1600-1700"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all text-gray-900"
                />
              </div>
            </div>

            <Button
              onClick={handleSearch}
              disabled={isSearching}
              className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white py-3 shadow-lg"
            >
              {isSearching ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Searching...
                </>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Search Ancestors
                </>
              )}
            </Button>
          </div>

          {searchResults.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Search Results</h2>
              <div className="space-y-4">
                {searchResults.map((person, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="bg-white rounded-xl shadow-lg p-6 border border-gray-200 hover:shadow-xl transition-all"
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-gray-900 mb-3">{person.name}</h3>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">Birth:</span>
                            <span className="ml-2 text-gray-900 font-medium">{person.birthYear}</span>
                          </div>
                          <div>
                            <span className="text-gray-600">Death:</span>
                            <span className="ml-2 text-gray-900 font-medium">{person.deathYear}</span>
                          </div>
                          <div>
                            <span className="text-gray-600">Location:</span>
                            <span className="ml-2 text-gray-900 font-medium">{person.location}</span>
                          </div>
                          <div>
                            <span className="text-gray-600">Occupation:</span>
                            <span className="ml-2 text-gray-900 font-medium">{person.occupation}</span>
                          </div>
                        </div>
                        <p className="mt-4 text-gray-700 italic">{person.notes}</p>
                      </div>
                      <Button
                        onClick={() => handleAddToTree(person)}
                        className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white ml-4"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add to Tree
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </motion.div>
      </Layout>
    </>
  );
};

export default AncestorSearch;
