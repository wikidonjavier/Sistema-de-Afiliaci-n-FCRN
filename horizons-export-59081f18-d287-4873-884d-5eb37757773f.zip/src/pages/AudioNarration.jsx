
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { useGenealogy } from '@/contexts/GenealogyContext';
import { useToast } from '@/components/ui/use-toast';
import { Volume2, Play, Pause, Download, Sparkles, RefreshCw } from 'lucide-react';

const AudioNarration = () => {
  const { familyMembers } = useGenealogy();
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);
  const [hasAudio, setHasAudio] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState('professional');

  const voices = [
    { id: 'professional', name: 'Professional Narrator', description: 'Clear and authoritative' },
    { id: 'warm', name: 'Warm & Friendly', description: 'Engaging and personal' },
    { id: 'historical', name: 'Historical Tone', description: 'Documentary style' }
  ];

  const handleGenerateNarration = () => {
    if (familyMembers.length === 0) {
      toast({
        title: "No Data Available",
        description: "Please add family members before generating narration",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    setTimeout(() => {
      setHasAudio(true);
      setIsGenerating(false);
      toast({
        title: "Narration Generated",
        description: "Your family history narration is ready to play"
      });
    }, 3000);
  };

  const handlePlayPause = () => {
    if (!hasAudio) return;
    setIsPlaying(!isPlaying);
    toast({
      title: isPlaying ? "Paused" : "Playing",
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const handleDownload = () => {
    toast({
      title: "Download Audio",
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <>
      <Helmet>
        <title>Audio Narration - Sephardic Genealogy Research</title>
        <meta name="description" content="Listen to AI-generated audio narrations of your Sephardic family history" />
      </Helmet>
      <Layout>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="space-y-8"
        >
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Audio Narration</h1>
            <p className="text-gray-600">Listen to your family history brought to life</p>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-8 border border-purple-200">
            <div className="flex items-center gap-3 mb-6">
              <Sparkles className="w-8 h-8 text-purple-600" />
              <h2 className="text-2xl font-bold text-gray-900">AI-Generated Voice Narration</h2>
            </div>
            <p className="text-gray-700 mb-6">
              Our advanced AI creates natural-sounding narrations of your family history, complete with 
              emotional inflection and historical context. Choose your preferred voice style below.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              {voices.map((voice) => (
                <button
                  key={voice.id}
                  onClick={() => setSelectedVoice(voice.id)}
                  className={`p-4 rounded-lg border-2 transition-all text-left ${
                    selectedVoice === voice.id
                      ? 'border-purple-600 bg-purple-50'
                      : 'border-gray-300 bg-white hover:border-purple-400'
                  }`}
                >
                  <h3 className="font-semibold text-gray-900 mb-1">{voice.name}</h3>
                  <p className="text-sm text-gray-600">{voice.description}</p>
                </button>
              ))}
            </div>

            <Button
              onClick={handleGenerateNarration}
              disabled={isGenerating}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-4 shadow-lg"
            >
              {isGenerating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                  Generating Narration...
                </>
              ) : (
                <>
                  <RefreshCw className="w-5 h-5 mr-3" />
                  Generate Audio Narration
                </>
              )}
            </Button>
          </div>

          {hasAudio && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-xl shadow-2xl p-8 border border-gray-200"
            >
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Your Family History Narration</h2>
              
              <div className="bg-gradient-to-r from-gray-100 to-gray-200 rounded-xl p-8 mb-6">
                <div className="flex items-center justify-center mb-6">
                  <Volume2 className="w-16 h-16 text-purple-600" />
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <span>0:00</span>
                    <span>5:42</span>
                  </div>
                  <div className="w-full bg-gray-300 rounded-full h-2">
                    <motion.div
                      className="bg-gradient-to-r from-purple-600 to-pink-600 h-2 rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: isPlaying ? '100%' : '0%' }}
                      transition={{ duration: 342, ease: 'linear' }}
                    />
                  </div>
                </div>

                <div className="flex justify-center gap-4 mt-8">
                  <Button
                    onClick={handlePlayPause}
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full w-16 h-16 shadow-lg"
                  >
                    {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8 ml-1" />}
                  </Button>
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={handleDownload}
                  className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white shadow-lg"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download MP3
                </Button>
                <Button
                  onClick={handleGenerateNarration}
                  variant="outline"
                  className="flex-1 border-2 border-gray-300 hover:border-purple-600 hover:bg-purple-50"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Regenerate
                </Button>
              </div>
            </motion.div>
          )}

          <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl p-6 border border-amber-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">What's Included</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-gray-700">
              <li className="flex items-center">
                <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                Complete family lineage narration
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                Historical context and background
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                Notable events and milestones
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                Cultural and religious heritage
              </li>
            </ul>
          </div>
        </motion.div>
      </Layout>
    </>
  );
};

export default AudioNarration;
