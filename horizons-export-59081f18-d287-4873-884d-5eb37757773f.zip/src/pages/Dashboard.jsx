
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useGenealogy } from '@/contexts/GenealogyContext';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Search, Users, FileText, Volume2, Video, Plus } from 'lucide-react';

const Dashboard = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { familyMembers, searchHistory, reports } = useGenealogy();

  const stats = [
    { label: 'Family Members', value: familyMembers.length, icon: Users, color: 'from-blue-500 to-blue-600' },
    { label: 'Searches', value: searchHistory.length, icon: Search, color: 'from-green-500 to-green-600' },
    { label: 'Reports', value: reports.length, icon: FileText, color: 'from-purple-500 to-purple-600' }
  ];

  const features = [
    {
      title: 'Ancestor Search',
      description: 'Search and discover your Sephardic ancestors',
      icon: Search,
      path: '/search',
      color: 'bg-gradient-to-br from-blue-500 to-blue-600'
    },
    {
      title: 'Family Tree',
      description: 'Visualize and manage your family connections',
      icon: Users,
      path: '/family-tree',
      color: 'bg-gradient-to-br from-green-500 to-green-600'
    },
    {
      title: 'Generate Reports',
      description: 'Create detailed PDF genealogical reports',
      icon: FileText,
      path: '/reports',
      color: 'bg-gradient-to-br from-purple-500 to-purple-600'
    },
    {
      title: 'Audio Narration',
      description: 'Listen to your family history narrated',
      icon: Volume2,
      path: '/narration',
      color: 'bg-gradient-to-br from-orange-500 to-orange-600'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Dashboard - Sephardic Genealogy Research</title>
        <meta name="description" content="Access your genealogical research dashboard with family trees, reports, and AI-powered ancestor search" />
      </Helmet>
      <Layout>
        <div className="space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Welcome back, {user?.name}!</h1>
            <p className="text-gray-600">Your genealogical research assistant is ready to help</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-xl shadow-lg p-6 border border-gray-200 hover:shadow-xl transition-shadow"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                    <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                  <div className={`p-4 rounded-full bg-gradient-to-br ${stat.color}`}>
                    <stat.icon className="w-8 h-8 text-white" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Research Tools</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.4 + index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  onClick={() => navigate(feature.path)}
                  className="bg-white rounded-xl shadow-lg overflow-hidden cursor-pointer border border-gray-200 hover:shadow-2xl transition-all"
                >
                  <div className={`${feature.color} p-6 flex items-center justify-center`}>
                    <feature.icon className="w-12 h-12 text-white" />
                  </div>
                  <div className="p-6">
                    <h3 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h3>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {familyMembers.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="bg-gradient-to-r from-amber-100 to-orange-100 rounded-xl p-8 border border-amber-200"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Start Your Research</h3>
                  <p className="text-gray-700">Begin by adding your first family member or searching for ancestors</p>
                </div>
                <Button
                  onClick={() => navigate('/search')}
                  className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white shadow-lg"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Get Started
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </Layout>
    </>
  );
};

export default Dashboard;
