
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { useGenealogy } from '@/contexts/GenealogyContext';
import { useToast } from '@/components/ui/use-toast';
import { FileText, Download, Eye, Plus, Calendar } from 'lucide-react';

const Reports = () => {
  const { familyMembers, reports, addReport } = useGenealogy();
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerateReport = () => {
    if (familyMembers.length === 0) {
      toast({
        title: "No Data Available",
        description: "Please add family members before generating a report",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    setTimeout(() => {
      const report = addReport({
        title: `Genealogical Report - ${new Date().toLocaleDateString()}`,
        type: 'Complete Family Tree',
        memberCount: familyMembers.length,
        pages: Math.ceil(familyMembers.length / 3),
        format: 'PDF'
      });
      setIsGenerating(false);
      toast({
        title: "Report Generated",
        description: "Your genealogical report has been created successfully"
      });
    }, 2000);
  };

  const handleDownload = (reportId) => {
    toast({
      title: "PDF Download",
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const handlePreview = (reportId) => {
    toast({
      title: "Report Preview",
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <>
      <Helmet>
        <title>Reports - Sephardic Genealogy Research</title>
        <meta name="description" content="Generate and download detailed PDF genealogical reports of your family history" />
      </Helmet>
      <Layout>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="space-y-8"
        >
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">Genealogical Reports</h1>
              <p className="text-gray-600">Generate professional PDF reports of your family history</p>
            </div>
            <Button
              onClick={handleGenerateReport}
              disabled={isGenerating}
              className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white shadow-lg"
            >
              {isGenerating ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Generating...
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4 mr-2" />
                  Generate New Report
                </>
              )}
            </Button>
          </div>

          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Report Features</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-gray-700">
              <li className="flex items-center">
                <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                Complete family tree visualization
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                Detailed biographical information
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                Historical context and notes
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                Professional PDF formatting
              </li>
            </ul>
          </div>

          {reports.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-xl shadow-lg p-12 text-center border border-gray-200"
            >
              <FileText className="w-20 h-20 text-gray-400 mx-auto mb-6" />
              <h2 className="text-2xl font-bold text-gray-900 mb-4">No Reports Yet</h2>
              <p className="text-gray-600 mb-8">Generate your first genealogical report to get started</p>
            </motion.div>
          ) : (
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-gray-900">Generated Reports</h2>
              {reports.map((report, index) => (
                <motion.div
                  key={report.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="bg-white rounded-xl shadow-lg p-6 border border-gray-200 hover:shadow-xl transition-all"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900 mb-3">{report.title}</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Type:</span>
                          <span className="ml-2 text-gray-900 font-medium">{report.type}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Members:</span>
                          <span className="ml-2 text-gray-900 font-medium">{report.memberCount}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Pages:</span>
                          <span className="ml-2 text-gray-900 font-medium">{report.pages}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Format:</span>
                          <span className="ml-2 text-gray-900 font-medium">{report.format}</span>
                        </div>
                      </div>
                      <div className="mt-3 flex items-center text-sm text-gray-600">
                        <Calendar className="w-4 h-4 mr-2" />
                        Created: {new Date(report.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="flex gap-2 ml-4">
                      <Button
                        onClick={() => handlePreview(report.id)}
                        variant="outline"
                        className="border-2 border-gray-300 hover:border-blue-600 hover:bg-blue-50"
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        Preview
                      </Button>
                      <Button
                        onClick={() => handleDownload(report.id)}
                        className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </Layout>
    </>
  );
};

export default Reports;
