
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider } from '@/contexts/AuthContext';
import { GenealogyProvider } from '@/contexts/GenealogyContext';
import ProtectedRoute from '@/components/ProtectedRoute';
import Login from '@/pages/Login';
import Dashboard from '@/pages/Dashboard';
import FamilyTree from '@/pages/FamilyTree';
import AncestorSearch from '@/pages/AncestorSearch';
import Reports from '@/pages/Reports';
import AudioNarration from '@/pages/AudioNarration';

function App() {
  return (
    <AuthProvider>
      <GenealogyProvider>
        <Router>
          <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-red-50">
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/family-tree"
                element={
                  <ProtectedRoute>
                    <FamilyTree />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/search"
                element={
                  <ProtectedRoute>
                    <AncestorSearch />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/reports"
                element={
                  <ProtectedRoute>
                    <Reports />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/narration"
                element={
                  <ProtectedRoute>
                    <AudioNarration />
                  </ProtectedRoute>
                }
              />
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
            </Routes>
            <Toaster />
          </div>
        </Router>
      </GenealogyProvider>
    </AuthProvider>
  );
}

export default App;
