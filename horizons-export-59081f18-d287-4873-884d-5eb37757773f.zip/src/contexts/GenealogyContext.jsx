
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

const GenealogyContext = createContext();

export const useGenealogy = () => {
  const context = useContext(GenealogyContext);
  if (!context) {
    throw new Error('useGenealogy must be used within GenealogyProvider');
  }
  return context;
};

export const GenealogyProvider = ({ children }) => {
  const { user } = useAuth();
  const [familyMembers, setFamilyMembers] = useState([]);
  const [searchHistory, setSearchHistory] = useState([]);
  const [reports, setReports] = useState([]);

  useEffect(() => {
    if (user) {
      const storedMembers = localStorage.getItem(`genealogy_members_${user.id}`);
      const storedHistory = localStorage.getItem(`genealogy_history_${user.id}`);
      const storedReports = localStorage.getItem(`genealogy_reports_${user.id}`);
      
      if (storedMembers) setFamilyMembers(JSON.parse(storedMembers));
      if (storedHistory) setSearchHistory(JSON.parse(storedHistory));
      if (storedReports) setReports(JSON.parse(storedReports));
    }
  }, [user]);

  const addFamilyMember = (member) => {
    const newMember = {
      id: Date.now().toString(),
      ...member,
      createdAt: new Date().toISOString()
    };
    const updated = [...familyMembers, newMember];
    setFamilyMembers(updated);
    if (user) {
      localStorage.setItem(`genealogy_members_${user.id}`, JSON.stringify(updated));
    }
    return newMember;
  };

  const updateFamilyMember = (id, updates) => {
    const updated = familyMembers.map(m => m.id === id ? { ...m, ...updates } : m);
    setFamilyMembers(updated);
    if (user) {
      localStorage.setItem(`genealogy_members_${user.id}`, JSON.stringify(updated));
    }
  };

  const deleteFamilyMember = (id) => {
    const updated = familyMembers.filter(m => m.id !== id);
    setFamilyMembers(updated);
    if (user) {
      localStorage.setItem(`genealogy_members_${user.id}`, JSON.stringify(updated));
    }
  };

  const addSearchRecord = (record) => {
    const newRecord = {
      id: Date.now().toString(),
      ...record,
      timestamp: new Date().toISOString()
    };
    const updated = [newRecord, ...searchHistory];
    setSearchHistory(updated);
    if (user) {
      localStorage.setItem(`genealogy_history_${user.id}`, JSON.stringify(updated));
    }
  };

  const addReport = (report) => {
    const newReport = {
      id: Date.now().toString(),
      ...report,
      createdAt: new Date().toISOString()
    };
    const updated = [newReport, ...reports];
    setReports(updated);
    if (user) {
      localStorage.setItem(`genealogy_reports_${user.id}`, JSON.stringify(updated));
    }
    return newReport;
  };

  const value = {
    familyMembers,
    searchHistory,
    reports,
    addFamilyMember,
    updateFamilyMember,
    deleteFamilyMember,
    addSearchRecord,
    addReport
  };

  return <GenealogyContext.Provider value={value}>{children}</GenealogyContext.Provider>;
};
