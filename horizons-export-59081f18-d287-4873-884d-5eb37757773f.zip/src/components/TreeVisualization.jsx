
import React from 'react';
import { motion } from 'framer-motion';
import { User, MapPin, Calendar, Briefcase } from 'lucide-react';

const TreeVisualization = ({ members }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Family Members</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {members.map((member, index) => (
          <motion.div
            key={member.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
            className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-xl p-6 border-2 border-amber-200 hover:border-amber-400 transition-all hover:shadow-lg"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-r from-amber-600 to-orange-600 p-3 rounded-full">
                <User className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">{member.name}</h3>
            </div>

            <div className="space-y-2 text-sm">
              {(member.birthYear || member.deathYear) && (
                <div className="flex items-center text-gray-700">
                  <Calendar className="w-4 h-4 mr-2 text-amber-600" />
                  <span>
                    {member.birthYear || '?'} - {member.deathYear || 'Present'}
                  </span>
                </div>
              )}

              {member.birthPlace && (
                <div className="flex items-center text-gray-700">
                  <MapPin className="w-4 h-4 mr-2 text-amber-600" />
                  <span>{member.birthPlace}</span>
                </div>
              )}

              {member.occupation && (
                <div className="flex items-center text-gray-700">
                  <Briefcase className="w-4 h-4 mr-2 text-amber-600" />
                  <span>{member.occupation}</span>
                </div>
              )}

              {member.notes && (
                <p className="text-gray-600 italic mt-3 pt-3 border-t border-amber-200">
                  {member.notes}
                </p>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default TreeVisualization;
