
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { BookOpen, LogOut, LayoutDashboard, Search, Users, FileText, Volume2 } from 'lucide-react';

const Layout = ({ children }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { logout, user } = useAuth();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/search', icon: Search, label: 'Search' },
    { path: '/family-tree', icon: Users, label: 'Family Tree' },
    { path: '/reports', icon: FileText, label: 'Reports' },
    { path: '/narration', icon: Volume2, label: 'Narration' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-red-50">
      <nav className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('/dashboard')}>
              <BookOpen className="w-8 h-8 text-amber-600" />
              <span className="text-xl font-bold text-gray-900">Sephardic Genealogy</span>
            </div>

            <div className="hidden md:flex items-center gap-2">
              {navItems.map((item) => (
                <Button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  variant={location.pathname === item.path ? 'default' : 'ghost'}
                  className={
                    location.pathname === item.path
                      ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white'
                      : 'text-gray-700 hover:bg-amber-50'
                  }
                >
                  <item.icon className="w-4 h-4 mr-2" />
                  {item.label}
                </Button>
              ))}
            </div>

            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-600 hidden sm:block">{user?.email}</span>
              <Button
                onClick={handleLogout}
                variant="outline"
                className="border-2 border-gray-300 hover:border-red-600 hover:bg-red-50 hover:text-red-600"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="md:hidden bg-white border-b border-gray-200 shadow-sm">
        <div className="flex overflow-x-auto px-4 py-2 gap-2">
          {navItems.map((item) => (
            <Button
              key={item.path}
              onClick={() => navigate(item.path)}
              size="sm"
              variant={location.pathname === item.path ? 'default' : 'ghost'}
              className={
                location.pathname === item.path
                  ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white whitespace-nowrap'
                  : 'text-gray-700 hover:bg-amber-50 whitespace-nowrap'
              }
            >
              <item.icon className="w-4 h-4 mr-2" />
              {item.label}
            </Button>
          ))}
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          {children}
        </motion.div>
      </main>

      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <BookOpen className="w-6 h-6 text-amber-600" />
              <span className="text-sm text-gray-600">Sephardic Genealogy Research © 2025</span>
            </div>
            <span className="text-sm text-gray-500">Preserving heritage, connecting generations</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
